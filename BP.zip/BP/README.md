# Add-on EGO

Add-on para Minecraft Bedrock creado por EGO AI.

Crea un ADD-ON PROFESIONAL COMPLETO para Minecraft Bedrock Edition llamado APOCALIPSIS Z: ULTIMATE SURVIVAL.

OBJETIVO:
Quiero una expansión de supervivencia zombi de mundo abierto, enorme, compleja, inmersiva y jugable. No quiero una demostración, un prototipo ni archivos de ejemplo. Quiero un proyecto completo y coherente, generado en una sola entrega.

1. SISTEMA DE ZOMBIS
- 15 tipos de zombis 

## Instalar
1. Abre el archivo .mcaddon (Minecraft lo importa solo).
2. En el mundo: Add-ons > activa el Behavior Pack y el Resource Pack.
3. Comandos para probarlo:
- `/give @s ego:pistol`
- `/give @s ego:shotgun`
- `/give @s ego:assault_rifle`
- `/give @s ego:sniper_rifle`
- `/give @s ego:baseball_bat`
- `/give @s ego:armor_chest`
- `/give @s ego:armor_head`
- `/give @s ego:armor_legs`
- `/give @s ego:energy_drink`
- `/give @s ego:first_aid_kit`
- `/give @s ego:bullet`
- `/give @s ego:shotgun_shell`

## Notas
- recipes/melee_knife.json usa ego:melee_knife, que no existe en este add-on.
- recipes/melee_crowbar.json usa ego:melee_crowbar, que no existe en este add-on.
- recipes/9mm_ammo.json usa ego:9mm_ammo, que no existe en este add-on.
- recipes/rifle_ammo.json usa ego:rifle_ammo, que no existe en este add-on.
- recipes/pistol_magazine.json usa ego:pistol_magazine, que no existe en este add-on.
- recipes/rifle_magazine.json usa ego:rifle_magazine, que no existe en este add-on.
- recipes/kevlar_vest.json usa ego:kevlar_vest, que no existe en este add-on.
- recipes/combat_helmet.json usa ego:combat_helmet, que no existe en este add-on.
- recipes/backpack.json usa ego:backpack, que no existe en este add-on.
- recipes/bandage.json usa ego:bandage, que no existe en este add-on.
- recipes/med_kit.json usa ego:med_kit, que no existe en este add-on.
- recipes/antidote.json usa ego:antidote, que no existe en este add-on.
- recipes/vaccine.json usa ego:vaccine, que no existe en este add-on.
- recipes/metal_plate.json usa ego:metal_plate, que no existe en este add-on.
- Las texturas de ítems y bloques son íconos generados automáticamente (16x16); puedes reemplazar los PNG de RP/textures.
- Si el script no corre, cambia la versión de @minecraft/server en BP/manifest.json (2.10.0) por una que tu juego soporte.


## Validación estructural de EGO AI
- Resultado: sin errores estructurales detectados
- Archivos revisados: 66

- Esta revisión estática no sustituye la importación y prueba dentro de Minecraft.
